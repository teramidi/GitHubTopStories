﻿namespace GitHubBestStories.Models
{
    public class RepositoryBestStoryIds : List<int>;
}
